<section class="content">
    <div class="container-fluid">
        <div class="block-header">
            <h2>PRODUK</h2>
        </div>

        <!-- Widgets -->
        <div class="row clearfix">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="info-box-3 bg-gradient hover-zoom-effect">
                    <div class="icon">
                        <i class="material-icons">account_circle</i>
                    </div>
                    <div class="content">
                        <div class="text">JUMLAH PRODUK</div>
                        <div class="number count-to" data-from="0" data-to="125" data-speed="15" data-fresh-interval="20"></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="info-box-3 bg-gradient-red hover-zoom-effect">
                    <div class="icon">
                        <i class="material-icons">new_releases</i>
                    </div>
                    <div class="content">
                        <div class="text">PRODUK DIBAWAH LIMIT</div>
                        <div class="number count-to" data-from="0" data-to="257" data-speed="1000" data-fresh-interval="20"></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="info-box-3 bg-gradient-green hover-zoom-effect">
                    <div class="icon">
                        <i class="material-icons">playlist_add_check</i>
                    </div>
                    <div class="content">
                        <div class="text">PRODUK AMAN LIMIT</div>
                        <div class="number count-to" data-from="0" data-to="243" data-speed="1000" data-fresh-interval="20"></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="info-box-3 bg-gradient-blue hover-zoom-effect">
                    <div class="icon">
                        <i class="material-icons">person_add</i>
                    </div>
                    <div class="content">
                        <div class="text">PRODUK BARU</div>
                        <div class="number count-to" data-from="0" data-to="1225" data-speed="1000" data-fresh-interval="20"></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- #END# Widgets -->
        <!-- CPU Usage -->
        <div class="row clearfix">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                <div class="card-table">
                    <div class="header">
                        <div class="row clearfix">
                           <a href="index.php?tambah-produk"><button type="button" class="btn bg-gradient btn-circle waves-effect waves-circle waves-float" style="margin-left: 10px;">
                                <i class="material-icons">add</i>
                            </button></a>
                        </div>
                        <ul class="header-dropdown m-r--5">
                            <li class="dropdown">
                                <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                    <i class="material-icons">more_vert</i>
                                </a>
                                <ul class="dropdown-menu pull-right">
                                    <li><a href="javascript:void(0);">Action</a></li>
                                    <li><a href="javascript:void(0);">Another action</a></li>
                                    <li><a href="javascript:void(0);">Something else here</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>

                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs tab-nav-right" role="tablist" style="padding-left: 5px;">
                        <li role="presentation" class="active">
                            <a href="#messages_only_icon_title" data-toggle="tab">
                                <i class="material-icons">call_to_action</i> PRODUK
                            </a>
                        </li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane in active" id="messages_only_icon_title">
                           <div class="body">
                            <table class="table table-hover dataTable js-exportable">
                                <?php

                                    include 'table_produk.php';

                                    ?>
                            </table>
                        </div>
                    </div>
                    <div role="tabpanel" class="tab-pane" id="settings_only_icon_title">
                        <div class="body">
                            <div class="body">
                                <div class="row clearfix">
                                    <div class="col-sm-3">
                                        <p><b>Bulan</b></p>
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="material-icons">date_range</i>
                                            </span>
                                            <select name="id_pelanggan" class="form-control show-tick" data-live-search="true">
                                                <?php
                                                include '../config/koneksi.php';

                                                $queryproduk = mysqli_query($konek, "SELECT id_order_penjualan, MONTHNAME(tanggal_order) as Bulan FROM order_penjualan GROUP BY Bulan");
                                                if($queryproduk == false){
                                                    die ("Terdapat Kesalahan : ". mysqli_error($konek));
                                                }
                                                while ($produk = mysqli_fetch_array($queryproduk)){
                                                    echo "<option value='$produk[id_order_penjualan]'>$produk[Bulan]</option>";
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <button class="btn btn-lg bg-gradient waves-effect">SET PERAMALAN</button>
                            </div>
                        </div>
                    </div>
                </div>
             </div>
        </div>
        <!-- #END# Tabs With Only Icon Title -->

                </div>
            </div>
        </div>
        <!-- #END# CPU Usage -->
    </div>
</section>
